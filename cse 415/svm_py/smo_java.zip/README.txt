SVM-JAVA: A simple Java implementation of SMO (Sequential Minimal Optimization) for training SVM

Developed by
Xiaoqian Jiang (xiaoqian@cs.cmu.edu)
Hwanjo Yu (hwanjoyu@postech.ac.kr)


Using This Code:
This code is publicly available to facilitate research in the related areas of data mining and machine learning. If you publish material based on this code, please refer to the source as follows, to help others to obtain the same code and reproduce your experiments.

SVM-JAVA: A Java implementation of the SMO (Sequential Minimal Optimization) for training SVM. Department of Computer Science and Engineering, Pohang University of Science and Technology (POSTECH), http://iis.hwanjoyu.org/svm-java, 2008

Bibtex entry:
@MISC{POSTECH08svm-java, 
author = "X. Jiang and H. Yu", 
title = "{SVM-JAVA}: A Java Implementation of the {SMO} (Sequential Minimal Optimization) for training {SVM}",
institution = "Department of Computer Science and Engineering, Pohang University of Science and Technology (POSTECH)",
address = "http://iis.hwanjoyu.org/svm-java",
year = "2008" 
}


1. Files

	GetOpt.java:		The command argument parser for Java
	Smo.java:		The main source for the SMO program
	tic-tac-toe: 		Sample data file for dense format
	heart_scale: 		Sample data file for sparse format
	tic-tac-toe.binary: 	Sample data file for binary format

2. Tested platform
	Linux, Windows

3. How to compile
	% javac Smo.java
	% javac GetOpt.java

4. How to run
	Train:
	% java Smo -f [datafile] -d [column NO.] -Other parameters
	e.g., java Smo -f heart_scale -s
	e.g., java Smo -f tic-tac-toe -d 27
	e.g., java Smo -f tic-tac-toe.binary -b
	Test:
	% java Smo -f [datafile] -m [model file] -a
	e.g., java Smo -f tic-tac-toe -m java-svm.model -a

5. Parameters
	java Smo -h
	usage: -h
	-f  data_file_name		(default: java-svm.data)
	-m  svm_file_name		(default: java-svm.model)
	-o  output_file_name 		(default: java-svm.output)
	-n  N
	-d  d
	-c  C				(default: 0.05)	
	-t  tolerance			(default: 0.001)
	-e  epsilon			(default: 0.001)
	-p  two_sigma_squared		(default: 2)
	-l  (is_linear_kernel)		(default: RBF kernel)
	-s  (is_sparse_data)		(default: false)	
	-b  (is_binary)			(default: false)
	-a  (is_test_only)		(default: false)

5. Data format
	The data file is a flat text file, and each data point occupies one line.
	For dense format, attribute values are followed by the class label (+1 or -1). (See "tic-tac-toe")
	Sparse format is the same as that in libsvm or svm light. (See "heard_scale")
	For binary format, feature values are binary, so only the indexes are specified. (See "tic-tac-toe.binary")

6. Output
	java-svm.model: The SVM model file generated after training
	java-svm.output: Function outputs on the training data
	
7. Saving and loading model parameters
	The output order of the model paramters will be
	1. The number of attributes d.
	2. The flag is-sparse-data
	3. The flag is-binary
	4. The flag is-linear-kernel
	5. The threshold b
	6. If the linear kernel is used:
		(a) The weight vector w
	7. If non-linear kernel is used
		(a) Kernel paramters
		(b) The number of support vectors
		(c) The Lagrange multipliers of the support vectors
		(d) The support vectors, one per line

